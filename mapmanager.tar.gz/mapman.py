#!/usr/bin/env python

#si hay tiempo mirar esto y meter el csv https://docs.python.org/2/library/csv.html

import os     #for wraps
import sys    #for wraps
import re     #for regex

InFileName   = "data_all.txt"#imports the text file from the working directory
OutFileName1 = "2_period_" + InFileName
OutFileName2 = "1_period_" + InFileName
OutFileName3 = "3_all_" + InFileName#these three commands give a name to the output files

WriteOutFile = True

InFile = open(InFileName, 'r')# creates an object called InFile and the function "open" opens it in read mode ('r')
HeaderLine = 'code\tLat\tLong\tcount\tyear\tmonth'#defines the header line (this is going to be used in the ouput files.

if WriteOutFile:#the following scripts open the output files in writing mode so we can write on them
	OutFile1 = open(OutFileName1, 'w')
	OutFile1.write(HeaderLine + '\n')
	OutFile2 = open(OutFileName2, 'w')
	OutFile2.write(HeaderLine + '\n')
	OutFile3 = open(OutFileName3, 'w')
	OutFile3.write(HeaderLine + '\n')

LineNumber = 0#creates a variable that will number the header line of the imput file with "0"
print_key = raw_input('print code key? (yes/no):')#define the variable print_key giving the user the option of demanding to print a list with the codes and species
if print_key == 'yes':#if the user chooses to write yes the following scripts will be printed on the command line
	print os.popen('grep -E -o "(\,[A-Z]{4}\,\w+\s\w+,)" data_all.txt | sort -u -f').read()#calls shell to print the codes and species
	print os.popen('grep -E -o "(\,[A-Z]{4}\,\w+\,)" data_all.txt | sort -u -f').read()#calls shell to print the codes and species
	print os.popen('grep -E -o "(\,[A-Z]{2}\-[A-Z]{1}\,)" data_all.txt | sort -u -f').read()#calls shell to print the codes of unidentified species
desired_code = raw_input('Enter a code:')#allow the user to write an specific code
desired_code = desired_code.upper()#makes desired_code uppercase
desired_year = int(input('Enter a year (yyyy):'))#define desired_year by entering a year
desired_month = int(input('Enter a month (m):'))#define desired_month by entering a month (in number)

#make it a list
for Line in InFile:
	Line = Line.strip('\n')# Remove the line-ending characters
	ElementList = Line.split(',')
	date = re.search('\d+-\d+-\d+',Line)

	if LineNumber > 0:#define the list that are not the headline (in fact we eliminate the headline)
		code    = ElementList[4]
		Lat     = float(ElementList[2])
		Long    = float(ElementList[3])
		count   = ElementList[8]
		if count != '':
			count   = int(ElementList[8])
		date_list = date.group(0).split('-')#you take all the wildexpression and create a list from it separating it from the "-"
		year      = int(date_list[0])
		month     = int(date_list[1])

		if year == desired_year:#selects in the database only the year you have written in the raw data
			if code == desired_code:
				AllCodes = "%s\t%.5f\t%.5f\t%s\t%d\t%d" % (code, Lat, Long, count, year, month)
				if WriteOutFile:
					OutFile3.write(AllCodes + '\n')


				if month > desired_month:#selects the data of the higher months than the selected
					MoreSix = "%s\t%.5f\t%.5f\t%s\t%d\t%d" % (code, Lat, Long, count, year, month)
					if WriteOutFile:
						OutFile1.write(MoreSix + '\n')
				else:#creates another output with the rest of the months
					LessSix = "%s\t%.5f\t%.5f\t%s\t%d\t%d" % (code, Lat, Long, count, year, month)
					if WriteOutFile:
						OutFile2.write(LessSix + '\n')

	LineNumber += 1


#print element[element == 'HUWH'].count('HUWH')

InFile.close()
if WriteOutFile:
	OutFile1.close()
	OutFile2.close()
	OutFile3.close()
