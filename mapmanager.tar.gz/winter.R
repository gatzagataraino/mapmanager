#!/usr/bin/env Rscript

getwd()


data1 <- read.table("2_period_data_all.txt", header=TRUE, sep="\t") # Import data, tab-delimited with a header
#head(data$Lat)
library(marmap)

pdf("2period.pdf")
attach(data1)#use the variable names. if you don't do this, you will need to used the notation data$Lat


#define the geographic range of the map
exLong <- 5
xlim <- c(min(Long)-exLong,max(Long)+exLong)
ylim <- c(min(Lat)-exLong,max(Lat)+exLong)

europe <- getNOAA.bathy(lon1=xlim[1], lon2=xlim[2], lat1 = ylim[1], lat2 = ylim[2], resolution=4)

# Creating color palettes
# Create nice looking color palettes
blues <- c("lightsteelblue4", "lightsteelblue3", "lightsteelblue2", "lightsteelblue1")
greys <- c(grey(0.6), grey(0.93), grey(0.99))


plot(europe, image = TRUE, land = TRUE, lwd = 0.1, bpal = list(c(0, max(europe), greys),
                                                               c(min(europe), 0, blues)),xlim=xlim, ylim=ylim)

# Add coastline
plot(europe, n = 1, lwd = 0.1, add = TRUE)
points(Long , Lat, pch = 21, col = "black",bg = "yellow", cex = 1.3)



sight<-data.frame(table(data1$month))#counts row per month
library(ggplot2)
ggplot() +
  geom_bar(data=sight, aes(x=Var1, y=Freq, fill=Var1),
           stat="identity", colour="black") + 
  guides(fill=FALSE) +
  theme_bw() + ylab("nº sightnings") + xlab("month") +

theme(axis.text=element_text(size=17),
      axis.title=element_text(size=20,face="bold")) +
  theme(                              
    plot.background = element_blank(), 
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(), 
    panel.border = element_blank(), 
    panel.background = element_blank(),
    axis.line = element_line(size=.4)
  )

library(stats)

number<-tapply(count, month, sum)
lumnas<-length(number)
smoke <- matrix(c(number),ncol=lumnas,byrow=TRUE)
second<-t(smoke)
row<-unique(month, incomparables = FALSE)
perfection<-cbind(second, row)
evenmoreperfect<-data.frame(perfection)


evenmoreperfect$row <- factor(evenmoreperfect$row)
ggplot() +
  geom_bar(data=evenmoreperfect, aes(x=row, y=V1, fill=row),
           stat="identity", colour="black") + 
  guides(fill=FALSE) +
  theme_bw() + ylab("counts") + xlab("month") +
theme(axis.text=element_text(size=17),
      axis.title=element_text(size=20,face="bold")) +
  theme(                              
    plot.background = element_blank(), 
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(), 
    panel.border = element_blank(), 
    panel.background = element_blank(),
    axis.line = element_line(size=.4)
  )

dev.off()

