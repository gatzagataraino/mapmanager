#!/bin/bash
#this will run the scripts in the order they are written
mapman.py
summer.R
winter.R

#this will make the new directory
mkdir ./results/
#this will import all the results in the new folder
mv 1_*txt 2_*txt 3_*txt 1period.pdf 2period.pdf 2 ./results





echo "==========================================>YOU CAN FIND THE RESULTS IN THE RESULT FOLDER"

